// Данные о фильмах (можно расширять)
const movies = [
  {
    id: 1,
    title: "Интерстеллар",
    description: "Эпическая фантастика о путешествии сквозь червоточину в поисках нового дома для человечества.",
    showtimes: ["12:00", "15:30", "19:00", "22:15"]
  },
  {
    id: 2,
    title: "Начало",
    description: "Профессиональные воры, крадущие секреты из подсознания через сон.",
    showtimes: ["11:00", "14:15", "17:45", "21:00"]
  },
  {
    id: 3,
    title: "Паразиты",
    description: "Семья безработных хитростью проникает в дом богатой семьи.",
    showtimes: ["13:20", "16:40", "20:00"]
  }
];

// Инициализация localStorage для отзывов
function initReviews() {
  if (!localStorage.getItem('movieReviews')) {
    const reviews = {};
    movies.forEach(movie => {
      reviews[movie.id] = [];
    });
    localStorage.setItem('movieReviews', JSON.stringify(reviews));
  }
}

// Загрузка отзывов из localStorage
function loadReviews() {
  return JSON.parse(localStorage.getItem('movieReviews') || '{}');
}

// Сохранение отзыва
function saveReview(movieId, reviewText) {
  const reviews = loadReviews();
  if (!reviews[movieId]) reviews[movieId] = [];
  reviews[movieId].push(reviewText);
  localStorage.setItem('movieReviews', JSON.stringify(reviews));
  renderMovie(movieId); // Обновляем только нужный фильм
}

// Рендер одного фильма
function renderMovie(movieId) {
  const movie = movies.find(m => m.id === movieId);
  const reviews = loadReviews()[movieId] || [];

  const container = document.getElementById(`movie-${movieId}`);
  if (!container) return;

  let showtimesHtml = movie.showtimes.map(time => `<span class="showtime">${time}</span>`).join('');

  let reviewsHtml = '';
  if (reviews.length > 0) {
    reviewsHtml = reviews.map(r => `<div class="review">${r}</div>`).join('');
  } else {
    reviewsHtml = '<p>Отзывов пока нет.</p>';
  }

  container.innerHTML = `
    <h2 class="movie-title">${movie.title}</h2>
    <p class="movie-description">${movie.description}</p>
    <div class="showtimes">
      <h3>Расписание:</h3>
      ${showtimesHtml}
    </div>
    <div class="reviews-section">
      <h3>Отзывы:</h3>
      ${reviewsHtml}
      <div class="review-form">
        <textarea id="review-text-${movieId}" placeholder="Ваш отзыв..."></textarea>
        <button onclick="submitReview(${movieId})">Оставить отзыв</button>
      </div>
    </div>
  `;
}

// Глобальная функция для отправки отзыва (нужна для onclick)
window.submitReview = function(movieId) {
  const textarea = document.getElementById(`review-text-${movieId}`);
  const text = textarea.value.trim();
  if (text) {
    saveReview(movieId, text);
    textarea.value = '';
  }
};

// Рендер всех фильмов
function renderAllMovies() {
  const container = document.getElementById('movies-container');
  container.innerHTML = '';

  movies.forEach(movie => {
    const movieDiv = document.createElement('div');
    movieDiv.className = 'movie-card';
    movieDiv.id = `movie-${movie.id}`;
    container.appendChild(movieDiv);
    renderMovie(movie.id);
  });
}

// Инициализация при загрузке
document.addEventListener('DOMContentLoaded', () => {
  initReviews();
  renderAllMovies();
});