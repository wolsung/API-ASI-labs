import os
import time
import pytest
from selenium.webdriver.common.by import By


# Путь к локальному HTML-файлу
BASE_URL = "http://localhost:8000"


def take_screenshot(driver, name):
    """Сохраняет скриншот в папку screenshots"""
    os.makedirs("screenshots", exist_ok=True)
    path = f"screenshots/{name}.png"
    driver.save_screenshot(path)
    print(f"📸 Скриншот сохранён: {path}")


def test_page_loads_and_shows_movies(driver):
    """
    ТЕСТ 1: Проверяет, что страница загружается и отображаются карточки фильмов.
    Ожидается: минимум 3 фильма на странице.
    """
    driver.get(BASE_URL)
    time.sleep(1)  # дать JS загрузиться

    movie_cards = driver.find_elements(By.CLASS_NAME, "movie-card")
    take_screenshot(driver, "test_page_loads_and_shows_movies")

    assert len(movie_cards) == 3, f"Ожидалось 3 фильма, найдено: {len(movie_cards)}"


def test_can_submit_review(driver):
    """
    ТЕСТ 2: Проверяет возможность оставить отзыв под фильмом.
    Ожидается: после отправки отзыв появляется в списке.
    """
    driver.get(BASE_URL)
    time.sleep(1)

    # Находим первый фильм и поле ввода
    textarea = driver.find_element(By.ID, "review-text-1")
    submit_btn = driver.find_element(By.XPATH, "//button[contains(text(), 'Оставить отзыв')]")

    test_review = "Отличный фильм! Рекомендую."
    textarea.send_keys(test_review)
    submit_btn.click()
    time.sleep(0.5)

    # Проверяем, что отзыв появился
    reviews = driver.find_elements(By.CLASS_NAME, "review")
    review_texts = [r.text for r in reviews]
    take_screenshot(driver, "test_can_submit_review")

    assert test_review in review_texts, "Отзыв не появился на странице"


def test_showtimes_displayed_correctly(driver):
    """
    ТЕСТ 3: Проверяет, что расписание показов отображается.
    Ожидается: у первого фильма есть хотя бы 4 сеанса.
    """
    driver.get(BASE_URL)
    time.sleep(1)

    showtimes = driver.find_elements(By.CLASS_NAME, "showtime")
    take_screenshot(driver, "test_showtimes_displayed_correctly")

    assert len(showtimes) >= 4, f"Ожидалось минимум 4 сеанса, найдено: {len(showtimes)}"